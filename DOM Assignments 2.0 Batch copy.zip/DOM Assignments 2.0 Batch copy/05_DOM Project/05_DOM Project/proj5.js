let element = document.querySelector(".nav-center").children[2];
let newelement = document.createElement("a");

newelement.innerHTML = "Pro Subscription";
newelement.setAttribute("href", "index.html");
newelement.classList.add("btn");
element.appendChild(newelement);
