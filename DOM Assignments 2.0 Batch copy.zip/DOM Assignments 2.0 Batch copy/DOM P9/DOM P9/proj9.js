let n = document.getElementsByClassName("caption").item(0).children[1];
n.style.color = "red";
console.log(n);
// assignment2
let m = document.querySelector(".add-to-cart");
m.addEventListener("mouseover", function () {
  m.style.backgroundColor = "red";
});
m.addEventListener("mouseout", function () {
  m.style.backgroundColor = "hsl(158, 36%, 37%)";
});
