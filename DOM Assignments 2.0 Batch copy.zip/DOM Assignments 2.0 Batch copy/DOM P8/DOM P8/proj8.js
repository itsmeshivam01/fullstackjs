let a = document.getElementsByClassName("new")[0];
console.log(a);
let n = document.createElement("p");
n.textContent = "This is my custom heading";
n.classList.add("new-p");
let hr = document.createElement("hr");
hr.classList.add("hr-line");
console.log(hr);
a.append(hr);
a.append(n);
a.className += " overflow";
console.log(a.className);
// assignment2
// let body = document.getElementsByTagName("body");
document.body.style.backgroundImage = "none";
// assignment3
let s = document.getElementsByClassName("navbar");

console.log(s);
console.log(document.getElementsByClassName("list"));
let k2 = document.getElementsByClassName("collapse");
// k2.style.display = "none";
let button = document.querySelector(".navbar-toggler-icon");
button.addEventListener("click", function () {
  document
    .getElementsByClassName("navbar-collapse")[0]
    .classList.toggle("collapse");

  //   .classList.remove("collapse navbar-collapse");
  // console.log("button clicked");
});
