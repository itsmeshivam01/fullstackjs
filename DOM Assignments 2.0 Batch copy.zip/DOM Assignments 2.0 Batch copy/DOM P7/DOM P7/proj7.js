let remove_2 = document.getElementsByClassName("main__languages")[0];
console.log(remove_2);
let tag = remove_2.getElementsByTagName("a");
console.log(tag);
for (let i = 0; i < tag.length; i++) {
  if (tag[i].textContent.includes("2.0")) {
    console.log(tag[i]);
    tag[i].remove();
  }
}
//assignment 2
let s = document.getElementsByTagName("form")[0].children[0];
console.log(s);
s.placeholder = "INeuron";

let k = document.getElementsByClassName("main__form-btn")[0];
console.log(k);
k.disabled = false;
let inp = document.querySelector(".main__form-input");
inp.disabled = false;
console.log(inp);
document.querySelector(".main__form-input").value = 2;
console.log(document.querySelector(".main__form-input").value);

document
  .querySelector(".main__form-btn")
  .addEventListener("click", function () {
    console.log(document.querySelector(".main__form-input").value);
  });
