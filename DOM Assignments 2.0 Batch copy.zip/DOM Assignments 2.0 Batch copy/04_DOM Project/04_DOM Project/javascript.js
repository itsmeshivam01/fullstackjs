// let a = document.getElementsByClassName(
//   "clash-card__unit-stats clash-card__unit-stats--barbarian clearfix"
// )[0].children;

// for (let i = 0; i <= 2; i++) {
//   console.log(box.item(0));
//   box[i].style.backgroundColor = "red";
// }
// let b = a.children;
// console.log(a);
// for (let i = 0; i <= a.length; i++) {
//   console.log(a[i]);
// }
// box.style.backgroundColor = "one-third";
// let e = document.getElementsByClassName(
//   "clash-card__unit-stats clash-card__unit-stats--barbarian clearfix"
// ).collection[0];
// console.log(e);
// for (let i =0;i<)
let a = document.getElementsByClassName(
  "clash-card__unit-stats clash-card__unit-stats--barbarian clearfix"
)[0];
// console.log(a.children);
// console.log(a);
a.style.backgroundColor = "#ec9b3b";
// a.classList.remove("clearfix");
// a.classList.add("clash-card__unit-stats--barbarian");
// console.log(a);
// a.className = "clash-card__level--barbarian";
// console.log(a);
// a.classList.add("clash-card__unit-stats--barbarian");
let b = a.children;
// b.classname = "clash-card__level--barbarian";

// *console.log(b);

let a1 = document.getElementsByClassName(
  "clash-card__unit-stats clash-card__unit-stats--archer clearfix"
)[0];
let a2 = document.getElementsByClassName(
  "clash-card__unit-stats clash-card__unit-stats--archer clearfix"
)[0];
let ba1 = a1.children;

// console.log(ba1.item(0));
console.log(a1);
console.log(ba1);
a1.style.backgroundColor = "#ee5487";
for (let i = 0; i < b.length; i++) {
  // console.log(b[0]);
  s = b[i].children[0];
  t = b[i].children[1];
  s1 = ba1[i].children[0];
  t1 = ba1[i].children[1];

  // s.classname = "clash-card__unit-stats--barbarian";
  // s.classList.add("clash-card__unit-stats--barbarian");
  console.log(s);
  s.style.color = "White";
  t.style.color = "White";
  s1.style.color = "White";
  t1.style.color = "White";
}
// let s1 = document.querySelector(".slide-container").children;
// console.log(s1);

// for (let i = 0; i <= s1.length; i++) {
//   console.log(s1[i].children);
//   // let c = document.querySelector(".wrapper:nth-child(0)");
//   // console.log(c);
// }
let n = document.getElementsByClassName("clash-card__unit-stats");
console.log(n);
let arr = ["#ec9b3b", "#ee5487", "#f6901a", "#82bb30", "#4facff"];
for (let i = 0; i < n.length; i++) {
  n[i].style.backgroundColor = arr[i];
  // console.log(n[i]);
  for (let j = 0; j < 3; j++) {
    n[i].children[j].style.color = "White";
  }
}
