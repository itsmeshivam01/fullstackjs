const d = document.getElementsByClassName("mainLeftDetails")[0];
const e = document.getElementsByClassName("mainRight")[0];
for (let i = 0; i <= d.length; i++) {
  d[0].value = "FSJS 2.0";
  let a = d[0].value;
  d[1].value = "fsjs@ineuron.ai";
  let b = d[1].value;
  d[2].value = "Hello World";
  let c = d[2].value;
  //   console.log((d[0].value = "shivam"));
}
let list = e.getElementsByTagName("form")[0];
list[0].value = d[0].value;
console.log(list[0].value);
list[1].value = d[1].value;
list[2].value = d[2].value;
