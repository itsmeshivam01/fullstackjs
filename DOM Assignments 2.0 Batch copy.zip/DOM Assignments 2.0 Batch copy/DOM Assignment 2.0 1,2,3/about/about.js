let accordian = document.querySelectorAll(".accordian h3");
accordian.forEach((element) => {
  element.addEventListener("click", () => {
    let para = element.nextElementSibling;
    if (para.style.display === "block") {
      para.style.display = "none";
    } else {
      para.style.display = "block";
    }
  });
});
let aw = document.querySelector(".accordian-wrapper").childNodes;
console.log(aw);
for (let i = 0; i < aw.length; i++) {
  if (i % 2 != 0) {
    aw[i].style.backgroundColor = "#c79fe3";
    let par = aw[i].getElementsByTagName("p")[0];
    par.style.backgroundColor = "#EDEADE";
    // console.log(par);
  }
}
// task 2
const a = document.querySelector(".accordian-wrapper");
const d = document.createElement("div");
d.className = "accordian";
a.appendChild(d);
const d5 = document.querySelector(".accordian-wrapper").lastChild;
console.log(d5);
const h = document.createElement("h3");
const head = document.createTextNode("Score");
h.appendChild(head);
// d.appendChild(h);
// d.appendChild(n);
// h.innerHTML = "score";
d5.appendChild(h);
const n = document.createElement("p");
const text = document.createTextNode(
  "I posses a very good command  full stack developement technologies"
);

n.appendChild(text);
console.log(n);
d5.appendChild(n);
console.log(d5.childNodes);
console.log(a.childNodes);

// d.in(n, d.children[0]);
// console.log(d.children);
// console.log(d.firstChild);
// console.log(d.lastChild);
// console.log(d.nextElementSibling);

// console.log(a);
