"use strict";
// const element = document.getElementsByTagName("NAV");
// console.log(element);
// const ul = document.getElementsByTagName("UL");
// console.log(ul);
// let li = document.createElement("li");
// li.innerHTML = '<a href="#">Hire</a>';
// console.log(li);
// ul.appendChild(li);
// const element = document.getElementsById("NAV");
const ul = document.getElementsByTagName("UL")[0];
console.log(ul);
let li = document.createElement("li");
li.innerHTML = '<a href="#">Hire</a>';
console.log(li);
ul.appendChild(li);
const l = ul.getElementsByTagName("li")[2];
l.innerText = "Projects";
console.log(l);
//TASK2
let s = document.getElementsByClassName("search-field")[0];
let k = s.getElementsByTagName("input")[0];
k.placeholder = "Search by name";
//Task3
let p = document.getElementsByClassName("hero-left-section");
p = document.querySelector("p").getElementsByTagName("span")[1];
p.innerHTML = " a Freelancer";

p = document.querySelector("p").getElementsByTagName("span")[2];
p.innerHTML = "iNeuron Intelligence LTD.";
//Task5
const div = document.querySelector(".hero-right-section-btns");
let Button = document.createElement("Button");
Button.textContent = "Support Me!";
div.appendChild(Button);
console.log(Button);
