let img = document.getElementsByTagName("header")[0].firstChild;
console.log(img);
img.src = "assets/ineuron-logo.png";
let tag = document.querySelector(".app_price").children[0];
tag.textContent = "$10";
console.log(tag.textContent);
