let randomNumber = function () {
  return Math.floor(Math.random() * 101);
};
score = 100;
let number = randomNumber();
console.log(number);
// let userInput = document.getElementById("Number").value;
let container = document.getElementsByClassName("container")[0];
let submit = document.querySelector(".btn");
let paragraph = document.createElement("p");
container.appendChild(paragraph);
let attempt = 0;
function checkGuess() {
  attempt++;
  let userInput = Number.parseInt(document.getElementById("Number").value);
  //   userInput = Number.parseInt(userInput);
  if (userInput == number) {
    paragraph.textContent = `Congratulations! You guessed the correct number in ${attempt}.`;
    submit.removeEventListener("click", checkGuess);
  } else {
    if (number <= 95) {
      output = `The Number is between ${number - 5} and ${number + 5}`;
      console.log(`The Number is between ${number - 5} and ${number + 5}`);
    } else if (number > 0 && number <= 5) {
      output = `The Number is between 0 and ${number + 5}`;
      console.log(`The Number is between 0 and ${number + 5}`);
    } else {
      output = `The Number is between 100 and ${number - 5}`;
      console.log(`The Number is between 100 and ${number - 5}`);
    }

    paragraph.textContent = output;

    score -= 5;
    if (score < 1) {
      paragraph.textContent = "game over";
      console.log(score);
      submit.removeEventListener("click", checkGuess);
    } else {
      submit.addEventListener("click", checkGuess);
      console.log(score);
    }
  }
}
// function checkGuess() {
//   attempts++;
//   let userInput = Number.parseInt(document.getElementById("Number").value);
//   if (userInput === number) {
//     paragraph.textContent = `Congratulations! You guessed the correct number in ${attempts} attempts.`;
//     submit.removeEventListener("click", checkGuess);
//   } else {
//     if (number <= 95) {
//       paragraph.textContent = `The Number is between ${number - 5} and ${
//         number + 5
//       }`;
//       console.log(`The Number is between ${number - 5} and ${number + 5}`);
//     } else if (number > 0 && number <= 5) {
//       paragraph.textContent = `The Number is between 0 and ${number + 5}`;
//       console.log(`The Number is between 0 and ${number + 5}`);
//     } else {
//       paragraph.textContent = `The Number is between 100 and ${number - 5}`;
//       console.log(`The Number is between 100 and ${number - 5}`);
//     }

//     score -= 5;
//     if (score < 1) {
//       paragraph.textContent = `Game over. You did not guess the number. The correct number was ${number}.`;
//       submit.removeEventListener("click", checkGuess);
//     } else {
//       submit.addEventListener("click", checkGuess);
//     }
//   }
// }
submit.addEventListener("click", checkGuess);
